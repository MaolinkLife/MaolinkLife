$(document).ready(function() {
    $(".content_block").each(function() {
        $(this).append(
            "<link rel=\"stylesheet\" type=\"text/css\" href=\"http://insite.tinkoff.ru/departments/trading/procedures/procedure_underground/faq_spoiler_style.css\">"
        );
    });

    $('[spoiler-header-panel]').append("<div class=\"arrow\"><div class=\"icon\"></div></div>");
    $('[spoiler-header-panel]').click(function() {
        $(this).toggleClass('active');
        $(this).parent().children('div[spoiler-content]').slideToggle(400);
        $(this).children(".arrow").children(".icon").toggleClass('active-spoiler');
        return false;
    });

    $("[spoiler-box]").each(function() {
        var attr = $(this).attr("active");
        if (typeof attr !== undefined && typeof attr !== "undefined" && attr !== false) {
            $(this).children("[spoiler-header-panel]").trigger('click');
            $(this).children('div[spoiler-content]').slideToggle();
        }
    });

});