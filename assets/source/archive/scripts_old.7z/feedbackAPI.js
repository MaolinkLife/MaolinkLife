// Переменные только для отладки, потом можно будет изменить порядок 
var description = "";
var text_summary = "";
var error_description = "";
var fields = {};
var general_array = [];
var programm_loyality,
    service,
    system,
    product,
    component,
    text_description,
    functional,
    product_params,
    assignee;
var tags_array = [];
var labels = [];
var debugger_info = [];
var methodologist = "";
var stop_boolean = false;
var sr_text = "";
var jiraResponse = {};
var appropriateArray = [];
var jiraObject = [];
var timer = 0;
var timerId;
var error_text = "";

var maxTasks = 50; // Сколько за раз показываем максимум задач // нужно отладить

const debuggerInfo = {
    Call(call, arg, res) {
        if (typeof arguments[0] != "undefined" &&
            typeof arguments[0] != undefined &&
            arguments[0] !== null) {
            console.info("%cВызвана Функция :", "color: #00BFFF;", arguments[0]);
        }
        if (typeof arguments[1] != "undefined" &&
            typeof arguments[1] != undefined &&
            arguments[1] !== null) {
            console.info("%cАргументы : ", "color: #FF8C00;", arguments[1]);
        }
        if (typeof arguments[2] != "undefined" &&
            typeof arguments[2] != undefined &&
            arguments[2] !== null) {
            console.info("%cСгенерированные параметры : ", "color: #FF8C00;", arguments[2]);
        }
        return;
    }
}


/* Поиск задач */
const Search = {
    start: function(search_str) {
        if (search_str.length > 0) {
            $("[s-card-box]").hide();
            $("[s-card-box]").removeClass("search-item");

            var keywords = search_str.split(" ");

            $("[s-card-box]").each(function() {
                var text = $(this).text().toUpperCase();
                var foundKeywords = 0;

                for (var i in keywords) {
                    var keyword = keywords[i];

                    if (~text.indexOf(keyword.toUpperCase()) || ~text.indexOf(Search.convert_symbols("en", "ru", keyword).toUpperCase()) || ~text.indexOf(Search.convert_symbols("ru", "en", keyword).toUpperCase())) {
                        foundKeywords++;
                    }
                }

                if (foundKeywords == keywords.length) {
                    $(this).show();
                    $(this).addClass("search-item");
                }
            });

        } else {
            $("[s-card-box]").show();
            $("[s-card-box]").removeClass("search-item");
        }
    },
    convert_symbols: function(from, to, text) {
        let langSymbols = {
                ru: "йцукенгшщзхъ\\фывапролджэячсмитьбю.ёЙЦУКЕНГШЩЗХЪ/ФЫВАПРОЛДЖЭЯЧСМИТЬБЮ,Ё!\"№;%:?*()_+",
                en: "qwertyuiop[]\\asdfghjkl;\"zxcvbnm,./`QWERTYUIOP{}|ASDFGHJKL:\"ZXCVBNM<>?~!@#$%^&*()_+"
            },
            fromLang = langSymbols[from],
            toLang = langSymbols[to],
            resultText = "";
        for (var i = 0; i < text.length; i++) {
            var j = fromLang.indexOf(text.charAt(i));
            if (j < 0) {
                resultText += text.charAt(i);
            } else {
                resultText += toLang.charAt(j);
            }
        }
        return resultText;
    }
}


// Программы лояльности (статика)
var programm_loyality_array = [
    "Tinkoff Black",
    "Браво",
    "All Airlines",
    "S7",
    "Азбука Вкуса",
    "Перекресток",
    "Tinkoff Drive",
    "OneTwoTrip",
    "eBay",
    "AliExpress",
    "AllGames (ранее Kanobu)",
    "Rendez-Vous",
    "Lamoda",
    "Google Play",
    "Аура",
    "Планета",
    "Лето",
    "Аврора",
    "Вегас",
    "ПФК ЦСКА",
    "Mobile",
    "Junior",
    "Физтех-Союз",
    "WWF",
    "Яндекс.Плюс"
];

var startPromises = [];
var all_product_params_structure = {};
var all_product_structure = {};
var all_functional_structure = {};
var all_service_structure = {};
var direction_structure = {};
var all_system_structure = {};
var tags_structure = {};
var all_methodologist_structure = {};

// полусерверный запрос к файлам, откуда тащим инфу
startPromises.push(
    fetch("/departments/processes/test_libraries/feedback/json/feedback_param_products_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_product_params_structure : ", "color: #00BFFF;", result);
        }
        all_product_params_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_product_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_product_structure : ", "color: #00BFFF;", result);
        }
        all_product_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_functional_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_functional_structure : ", "color: #00BFFF;", result);
        }
        all_functional_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_service_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_service_structure : ", "color: #00BFFF;", result);
        }
        all_service_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_direction_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%cfeedback_direction_structure : ", "color: #00BFFF;", result);
        }
        direction_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_system_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_system_structure : ", "color: #00BFFF;", result);
        }
        all_system_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_tags_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%ctags_structure : ", "color: #00BFFF;", result);
        }
        tags_structure = result;
        return;
    }),
    fetch("/departments/processes/test_libraries/feedback/json/feedback_methodologist_structure.json").then(response => response.json()).then(result => {
        if (PROCEDURE_MODE === "manual") {
            console.log("%call_methodologist_structure : ", "color: #00BFFF;", result);
        }

        all_methodologist_structure = result;
        return;
    })
);


const investment_category_array = [
    "Ценные бумаги / Финансовые инструменты",
    "Брокерский счет",
    "ИИС",
    "ПИФ",
    "Доходность",
    "Валюта",
    "Вывод 24/7",
    "Депозитарные переводы",
    "Корпоративные действия",
    "Лимитные заявки",
    "Маржинальное кредитование",
    "Налоговая форма",
    "Налогообложение",
    "Премиум",
    "Приложение Инвестиции",
    "Робоэдвайзер",
    "Совершение сделок",
    "Стоп-заявки",
    "Режим торгов",
    "Терминал",
    "Пульс"
];

const travel_category_array = [
    "Авиабилеты",
    "Выбор места в самолете",
    "Действия с билетами",
    "Добавление ребенка в заказ",
    "Перевозка домашних животных",
    "Питание",
    "Помощь маломобильному пассажиру",
    "Провоз багажа",
    "Страхование путешествующих",
    "Условия для перевозки детей"
];


// Получаем индекс элемента внутри структуры
function get_index_element_from_structure(structure, param_value) {
    const local = Object.keys(structure).findIndex(item => item == param_value)
    if (PROCEDURE_MODE == "manual") {
        debuggerInfo.Call("get_index_element_from_structure", arguments, local);
    }
    return local;
}

// Возвращает индекс массива
function get_index_array(array, element) {
    if (PROCEDURE_MODE == "manual") {
        debuggerInfo.Call("get_index_array", arguments);
    }
    return array.findIndex(item => item == element);
}


// Функция добавляет уникальные элементы массива from_array в массив to_array
function generate_array(to_array, from_array) {
    for (var i in from_array) {
        if (to_array.findIndex(item => item == from_array[i]) == -1) {
            to_array.push(from_array[i]);
        }
    }
}



/* Функция генерирует HTML параметр «Другое» */
function debug_generate_other(id_param) {
    $("#param_" + id_param).children(".param-section-vertical").append("<div data-value=\"Другое\" data-tags=\"\" class=\"search-always-show\">Другое</div>");
}


// Показываем параметры с настройками 
function show_param_with_options(id_param, object) {
    let param = $("#param_" + id_param).children(".param-section-vertical");
    param.empty();
    object.sort();
    param.prepend(generate_html_content(object));
    show_param(id_param, null, object);
    debug_generate_other(id_param);
    check_to_hide_search_bar(object, id_param);
    procedure_prepare_search_params_update();
}


// Проверяем нужно ли скрывать поисковую строку
function check_to_hide_search_bar(array, id_param) {
    if (array.length - 1 <= 3) {
        $("#param_" + id_param).children().each(function() {
            if ($(this).hasClass("search-bar")) {
                $(this).hide();
            }
        });
    } else {
        $("#param_" + id_param).children().each(function() {
            if ($(this).hasClass("search-bar")) {
                $(this).show();
            }
        });
    }
}

// Генерирует контент параметров с тэгами
function generate_html_content(array) {
    var text = "";
    for (var i in array) {
        if (PROCEDURE_MODE === "manual") {
            console.log("%cСгенерированные параметры : ", "color: #FF8C00;", array[i]);
        }

        if (array[i] != "Другое") {
            if (PROCEDURE_MODE === "manual") {
                console.log("%cСгенерированные параметры : ", "color: #FF8C00;", "tags : ", tags_structure[array[i]]);
            }
            if (!!tags_structure[array[i]]) {
                tags = tags_structure[array[i]];
            } else {
                tags = "";
            }
            text += "<div data-value=\"" + array[i] + "\" data-tags=\"" + tags + "\" class=\"\" style=\"display: block;\">" + array[i] + "<span class=\"hidden\"></span></div>";
        }
    }
    return text;
}

// Конвертируем первую ступень структуры в массив
function get_array_from_structure(structure) {
    return Object.keys(structure);
}




// Генерируем общий список тематик
function generate_general_array() {
    generate_array(general_array, Object.keys(all_system_structure));
    generate_array(general_array, Object.keys(all_service_structure));
    generate_array(general_array, Object.keys(all_product_structure));
    generate_array(general_array, Object.keys(all_functional_structure));
    generate_array(general_array, Object.keys(all_product_params_structure));
    general_array.sort();
}


// Обнуляем переменные для заглушки
function resetting_variables() {
    component = null;
    system = null;
    functional = null;
    service = null;
    product_params = null;
    product = null;
}

/* Функция для отладки поисковой строки в параметрах */
function procedure_prepare_search_params_update() {
    $("body").on("focus", ".search-bar > input", function() {
        $(this).select();
    });

    $("body").on("input", ".search-bar > input", function() {
        procedure_param_do_search($(this).parents("[id^=param_]"), $(this).val());
        auto_params_search[$(this).parents("[id^=param_]").attr("id").slice(6)] = "";
    });

    $("body").on("click", ".search-bar-clr-btn", function() {
        if (!$param.attr("alreadyLogged") && !$param.attr("alreadyLoggedClick") && $param.hasClass("log")) {
            alwaysShowCount = $param.find(" .search-always-show").length;
            resCounter = $param.find(".param-section-vertical>div:visible").length - alwaysShowCount;
            param_id = $param.attr("id").replace("param_", "");
            procedure_search_param_log(param_id, $(this).val(), resCounter, $param.attr("turn_id"));
            $param.attr("alreadyLogged", "y");
            $param.attr("alreadyLoggedClick", "");

        }
        $(this).siblings("input").val("");
        $(this).siblings("input").focus();
        $param.attr("focusflag", "");
        procedure_param_do_search($(this).parents("[id^=param_]"), "");
        auto_params_search[$(this).parents("[id^=param_]").attr("id").slice(6)] = "";
    });

    $(".param-searchable [data-tags]").each(function() {
        $(this).append("<span class=\"hidden\">" + $(this).attr("data-tags") + "</span>");
    });

    $("body").on("focus", ".search-bar input", function() {
        $param = $(this).parents("[id*=param_]");
        $param.attr("focusflag", "y");
    });

    $("body").on("input", ".search-bar input", function() {
        $param = $(this).parents("[id*=param_]");
        if ($param.attr("focusflag")) {
            $param.attr("focusflag", "");
            time = new Date().valueOf();
            turn_id = PROCEDURE_OPEN_ID + "" + time;
            $param.attr("turn_id", turn_id);
        }

    });

    $("body").on("keydown", ".search-bar input", function(event) {
        $param = $(this).parents("[id*=param_]");
        if (event.which == 40) {
            if ($param.find(".param-hover:visible").length === 0) {
                if ($param.find(".param-selected:visible").length === 0) {
                    $param.find(".param-section-vertical > div:visible")
                        .first()
                        .addClass("param-hover");
                } else {
                    $param.find(".param-section-vertical > div.param-selected")
                        .nextAll("div:visible")
                        .first()
                        .addClass("param-hover");
                }
            } else if ($param.find(".param-section-vertical > div.param-hover").nextAll("div:visible").length > 0) {
                $param.find(".param-section-vertical > div.param-hover")
                    .removeClass("param-hover")
                    .nextAll("div:visible")
                    .first()
                    .not(".param-selected")
                    .addClass("param-hover");
            }
        } else if (event.which == 38) {
            if ($param.find(".param-hover").length === 0) {
                $param.find(".param-section-vertical > div.param-selected")
                    .prevAll("div:visible")
                    .first()
                    .addClass("param-hover");
            } else if ($param.find(".param-section-vertical > div.param-hover").prevAll("div:visible").length > 0) {
                $param.find(".param-section-vertical > div.param-hover")
                    .removeClass("param-hover")
                    .prevAll("div:visible")
                    .first()
                    .not(".param-selected")
                    .addClass("param-hover");
            }
        } else if (event.which == 13) {
            if ($param.find(".param-hover").length !== 0) {
                $param.find(".param-hover")
                    .removeClass("param-hover")
                    .trigger("click");
                $(this).blur();
            }
        }
        //Логирование поиска при нажатии Backspace и delete
        else if (event.which == 8 || event.which == 46) {
            if (!$param.attr("alreadyLogged") && $(this).val() != "" &&
                !$param.attr("alreadyLoggedClick") && $param.hasClass("log")) {
                alwaysShowCount = $param.find(" .search-always-show").length;
                resCounter = $param.find(".param-section-vertical>div:visible").length - alwaysShowCount;
                param_id = $param.attr("id").replace("param_", "");
                procedure_search_param_log(param_id, $(this).val(), resCounter, $param.attr("turn_id"));
                $param.attr("alreadyLogged", "y");
                $param.attr("alreadyLoggedClick", "");
            }
        } else {
            $param.attr("alreadyLogged", "");
            $param.attr("alreadyLoggedClick", "");
        }
    });
}

// Проверка компонентов внутри каждого из массивов
function switch_on_component(param_value) {
    if (get_index_array(direction_structure["Инвестиции"], param_value) != -1) {
        return "Инвестиции";
    } else if (get_index_array(direction_structure["Путешествия"], param_value) != -1) {
        return "Путешествия";
    } else {
        return "Сквозные процессы";
    }
}

// Генерируем компонент 
function generate_component() {
    /* В случае, если первым пунктом было выбрано другое, то компонент генерируем из второго пункта */
    if (Object.keys(direction_structure).findIndex(item => item == param("select_product")) != -1) {
        component = param("select_product");
    } else {
        if (param("select_product") == "Другое") {
            if (investment_category_array.findIndex(item => item == param("general_info")) != -1) {
                component = "Инвестиции";
            } else if (travel_category_array.findIndex(item => item == param("general_info")) != -1) {
                component = "Путешествия";
            } else {
                component = "Сквозные процессы";
            }
        } else {
            if (investment_category_array.findIndex(item => item == param("general_info")) != -1) {
                component = "Инвестиции";
            } else {
                component = switch_on_component(param("select_product"));
            }
        }
    }

}

// Генерируем заголовок 
function generate_summary() {
    text_summary = "";
    if (!!component) {
        text_summary += component + ".";
    }
    if (!!system) {
        text_summary += system + ".";
    }
    if (!!functional) {
        text_summary += functional + ".";
    }
    if (!!service) {
        text_summary += service + ".";
    }
    if (!!product_params) {
        text_summary += product_params + ".";
    }
    if (!!product) {
        text_summary += product + ".";
    }
    return text_summary;
}

// генерируем параметры процедуры
function generate_params_value() {
    resetting_variables();

    if (get_index_element_from_structure(all_product_structure, param("general_info")) != -1) {
        product = param("general_info");
        if (investment_category_array.findIndex(item => item == param("general_info")) != -1) {
            component = "Инвестиции";
        } else {
            component = switch_on_component(param("general_info"));
        }
        // Сервис
        if (get_index_element_from_structure(all_system_structure, param("select_product")) != -1) {
            system = param("select_product");
        }
        // Функционал
        else if (get_index_element_from_structure(all_functional_structure, param("select_product")) != -1) {
            functional = param("select_product");
        }
        // Услуга
        else if (get_index_element_from_structure(all_service_structure, param("select_product")) != -1) {
            service = param("select_product");
        }
        // Параметры продукта
        else if (get_index_element_from_structure(all_product_params_structure, param("select_product")) != -1) {
            if (param("general_info") == "Ценные бумаги / Финансовые инструменты" || param("select_product") == "Ценные бумаги / Финансовые инструменты") {
                if (param("select_product") == "Ценные бумаги / Финансовые инструменты") {
                    if (param("securities") == "Другое") {
                        product_params = param("select_product");
                    } else {
                        product_params = param("securities");
                    }
                } else {
                    if (param("select_product") == "Другое") {
                        product_params = param("general_info");
                    } else {
                        product_params = param("select_product");
                    }
                }
            } else {
                if (get_index_element_from_structure(all_product_params_structure, param("general_info")) != -1) {
                    product_params = param("general_info");
                } else {
                    product_params = param("select_product");
                }
            }
        }
    } else {
        generate_component();
        // Сервис
        if (get_index_element_from_structure(all_system_structure, param("general_info")) != -1) {
            system = param("general_info");
        }
        // Функционал
        else if (get_index_element_from_structure(all_functional_structure, param("general_info")) != -1) {
            functional = param("general_info");
        }
        // Услуга
        else if (get_index_element_from_structure(all_service_structure, param("general_info")) != -1) {
            service = param("general_info");
        }
        // Параметры продукта
        else if (get_index_element_from_structure(all_product_params_structure, param("general_info")) != -1) {
            if (param("general_info") == "Ценные бумаги / Финансовые инструменты" || param("select_product") == "Ценные бумаги / Финансовые инструменты") {
                if (param("select_product") == "Ценные бумаги / Финансовые инструменты") {
                    if (param("securities") == "Другое") {
                        product_params = param("select_product");
                    } else {
                        product_params = param("securities");
                    }
                } else {
                    if (param("select_product") == "Другое") {
                        product_params = param("general_info");
                    } else {
                        product_params = param("select_product");
                    }
                }
            } else if (get_index_array(all_product_params_structure[param("general_info")], param("select_product")) != -1) {
                product_params = param("general_info");
            } else {
                product_params = param("select_product");
            }
        }
        if (get_index_element_from_structure(all_product_structure, param("select_product")) != -1) {
            product = param("select_product");
        } else {
            product = null;
        }


    }

    //======================================================================
    if (PROCEDURE_MODE === "manual") {
        console.log("%c======================================================================", "color:red;");

        console.log("%ccomponent : ", "color: #FF8C00;", component);
        console.log("%csystem : ", "color: #FF8C00;", system);
        console.log("%cfunctional : ", "color: #FF8C00;", functional);
        console.log("%cservice : ", "color: #FF8C00;", service);
        console.log("%cproduct_params : ", "color: #FF8C00;", product_params);
        console.log("%cproduct : ", "color: #FF8C00;", product);
    }
    check_select_param();
}

// Проверяем был ли первым выбран продукт
function check_select_param() {
    if (PROCEDURE_MODE === "manual") {
        console.log("%cВызвана Функция :", "color: #00BFFF;", "check_select_param");
    }
    methodologist = "";
    var checker_param;
    if (component != "Сквозные процессы") {
        if (get_array_from_structure(all_product_structure).findIndex(item => item == param("general_info")) != -1) {
            if (param("select_product") == "Ценные бумаги / Финансовые инструменты") {
                if (param("securities") == "Другое") {
                    checker_param = param("select_product");
                } else {
                    checker_param = param("securities");
                }
            } else {
                if (param("select_product") == "Другое") {
                    checker_param = param("general_info");
                } else {
                    checker_param = param("select_product");
                }
            }
        } else {
            if (get_array_from_structure(all_product_structure).findIndex(item => item == param("select_product")) != -1) {
                checker_param = param("general_info");
            } else {
                if (param("general_info") == "Ценные бумаги / Финансовые инструменты") {
                    if (get_array_from_structure(investment_category_array).findIndex(item => item == param("select_product")) != -1) {
                        checker_param = param("select_product");
                    } else {
                        if (param("select_product") == "Акции" || param("select_product") == "Облигации" || param("select_product") == "ETF") {
                            checker_param = param("select_product");
                        } else {
                            checker_param = param("general_info");
                        }
                    }
                } else {
                    checker_param = param("general_info");
                }
            }
        }
        if (PROCEDURE_MODE === "manual") {
            console.log("%cСгенерированные параметры : ", "color: #FF8C00;", checker_param);
        }
        generate_methodologist(checker_param);
    } else {
        methodologist = "jirman";
        if (PROCEDURE_MODE === "manual") {
            console.log("%cСгенерированные параметры : ", "color: #FF8C00;", methodologist);
        }
    }
    // Пока с фиксированным временем задержка, так как не знаю, как отладить
    procedure_show_wait();
    setTimeout(function() {
        todoAfter(procedure_hide_wait);
    }, 1500);
}


// Генерируем методологов 
function generate_methodologist(param_value) {
    var checker_array = get_array_from_structure(all_methodologist_structure[component]);

    for (const i in (checker_array)) {
        if (all_methodologist_structure[component][checker_array[i]].findIndex(item => item == param_value) != -1) {
            methodologist = checker_array[i];
        }
    }
}


// Генерируем описание
function generate_text_description(value) {
    return text_description = value + `\n Сотрудник: ${USER_LOGIN} \n Клиент: ${SIEBEL["s_contact_id"]}\n Активность : ${SIEBEL["activity_id"]} \n Дата и время отправки ${date_str(today())+" "+ today("hour")+":"+today("min")+":"+today("sec")}`;
}


//====================================================================================================
// * 
// *  
// * 
//====================================================================================================


// Предзагрузочные настройки 
function preloader() {
    var direction = "";
    generate_general_array();

    programm_loyality_array.sort();

    $("#param_general_info").children(".param-section-vertical").prepend(generate_html_content(general_array));
    $("#param_programm_loyality").children(".param-section-vertical").prepend(generate_html_content(programm_loyality_array));

    procedure_prepare_search_params_update();

    if (USER_GROUPS.findIndex(item => item == 56) != -1) { // Это только для инфо поддержки
        show_param("general_info");
    } else {
        if ($.inArray(301, USER_GROUPS) != -1 || $.inArray(328, USER_GROUPS) != -1 || $.inArray(221, USER_GROUPS) != -1 || $.inArray(331, USER_GROUPS) != -1) {
            direction = "Путешествия";
            show_param("general_info", null, generate_list_from_direction(direction));
        } else if ($.inArray(127, USER_GROUPS) != -1 || $.inArray(145, USER_GROUPS) != -1 || $.inArray(135, USER_GROUPS) != -1 || $.inArray(323, USER_GROUPS) != -1 || $.inArray(332, USER_GROUPS) != -1 || $.inArray(108, USER_GROUPS) != -1) {
            direction = "Инвестиции";
            show_param("general_info", null, generate_list_from_direction(direction));
        }
    }
}


// Генерируем список в зависимости от направелния сотрудника 
// Получает направление в виде строки, возврашает список элементов, которые нужно показать 
function generate_list_from_direction(direction) {
    let x = Object.keys(all_product_structure);
    let array_to_show = [];
    let y = direction_structure[direction];
    for (const i in x) {
        if (y.findIndex(item => item == x[i]) != -1) {
            array_to_show.push(x[i]);
            let array_inv = all_product_structure[x[i]];
            for (const j in array_inv) {
                if (array_to_show.findIndex(item => item == array_inv[j]) == -1) {
                    array_to_show.push(array_inv[j]);
                }
            }
        }
    }
    return array_to_show;
}

//====================================================================================================
// * 
// * 
// * 
//====================================================================================================


// Вызываем эту функцию, когда сотрудник ждет кнопку Отправить. 
function save_feedback() {
    sr_text = $(".description-text").val();
    // Если сотрудник ничего не ввел, то говорим ему заполнить все обязательные поля
    console.log($(".description-text").val().length > 0);
    if ($(".description-text").val().length) {
        // Заглушка на случай зависания Siebel 
        if (stop_boolean == false) {
            stop_boolean = true;
            // Если все ок, то начинаем генерацию. 
            text_description = generate_text_description(sr_text);
            if (PROCEDURE_MODE === "manual") {
                console.log("text description :", text_description);
            }
            text_summary = generate_summary();
            // Переходим к регистрации SR
            create_sr();
            start_timer();
        } else if (stop_boolean == true) {
            save_feedback();
        }


    } else {
        procedure_make_step_error($("#step_1"));
        show_error(USER_FIRST_NAME + ", заполни описание предложения");

    }
}


// Запускаем таймер для отслеживания времени с нажатия кнопки до регистрации запроса.
function start_timer() {
    if (PROCEDURE_MODE === "manual") {
        console.log("%cВызвана Функция :", "color: #00BFFF;", "start_timer");
    }
    timer = 0;
    timerId = setInterval(function() {
        if (timer > 60) {
            timer++;
            error_text = "Превышен лимит ожидания от сервера<br><br>";
        } else {
            timer++;
        }
    }, 1000);
}

// 1. Регистрируем пустой SR
function create_sr() {
    procedure_add_postmessage({
        "source": "procedure",
        "tasks": [{
            "TASK": "add_new_sr",
            "SR_CODE": "Feedback.CustomerOffer"
        }]
    }, function() {
        hide("step_1");
        show_step("10");
        generate_input_data();
    });
}


// Формируем объект JSON
function generate_input_data() {
    if (param("securities") == "Акции" ||
        param("securities") == "Облигации" ||
        param("securities") == "ETF" ||
        param("select_product") == "Акции" ||
        param("select_product") == "Облигации" ||
        param("select_product") == "ETF") {

    } else {
        labels = [];
    }
    if (PROCEDURE_MODE === "manual") {
        console.log("%cВызвана Функция :", "color: #00BFFF;", "generate_input_data");
    }
    assignee = methodologist;
    fields = new Object();

    fields["issuetype"] = {
        "name": "Task"
    }; // Тип задачи 
    fields["project"] = {
        "key": "FEEDBACK"
    }; // Проект
    fields["assignee"] = {
        "name": assignee
    }; // Исполнитель
    fields["customfield_10702"] = 1; // Голоса
    fields["customfield_12101"] = {
        "name": methodologist
    }; // Методолог 

    // Заголовок
    if (!!text_summary) {
        fields["summary"] = text_summary;
    }

    // Описание
    if (!!text_description) {
        fields["description"] = text_description;
    }

    // Компонент 
    if (!!component) {
        fields["components"] = [{
            "name": component
        }];
    }

    // Продукт
    if (!!product) {
        fields["customfield_12000"] = {
            "value": product
        };
    }

    // Метки
    if (labels.length) {
        fields["labels"] = labels;
    }

    // Система
    if (!!system) {
        fields["customfield_12003"] = {
            "value": system
        };
    }

    // Программа лояльности
    if (!!programm_loyality) {
        fields["customfield_12006"] = {
            "value": programm_loyality
        };
    }

    // Параметры продукта
    if (!!product_params) {
        fields["customfield_12001"] = {
            "value": product_params
        };
    }

    // Функционал
    if (!!functional) {
        fields["customfield_12007"] = {
            "value": functional
        };
    }

    // Услуга
    if (!!service) {
        fields["customfield_12002"] = {
            "value": service
        };
    }
    let files = document.getElementById("addImage").files;
    if (typeof files == 'undefined') {
        files = [];
    }


    console.log(fields);
    console.log(files);

    sendDataInFile();




    // Категория
    //if (!!category) {fields["customfield_10704"] = {"value" : category};}

    // Подкатегория
    //if (!!subcategory) {fields["customfield_10806"] = {"value" : subcategory};}


    jiraResponse = createJiraTask(fields, files);
    setTimeout(function() {
        // После того, как сформировали - отправляем его в JIRA
        if (jiraResponse !== "undefined" && jiraResponse !== undefined) {
            if (param("securities") == "Акции" ||
                param("securities") == "Облигации" ||
                param("securities") == "ETF" ||
                param("select_product") == "Акции" ||
                param("select_product") == "Облигации" ||
                param("select_product") == "ETF") {
                description = `${jiraResponse.key} \n Добавление новой бумаги`;
            } else {
                description = `${jiraResponse.key} \n Предложение: ${sr_text}`;
            }
            // Заполняем ПО
            if (PROCEDURE_MODE == "auto") {
                sr_register_task(description);
            } else {
                after_sr_register();
            }
        } else {
            description = `[Номер задачи появится позже] \n Предложение: ${sr_text}`;

            // Заполняем ПО
            if (PROCEDURE_MODE == "auto") {
                sr_register_task(description);
            } else {
                after_sr_register();
            }

            if (typeof jiraResponse["errors"] != "undefined") {

                var $val = Object.values(jiraResponse.errors);
                var $key = Object.keys(jiraResponse.errors);
                var i = 0;
                while (i < $key.length) {
                    error_description += "\n\n• " + $key[i] + ": " + $val[i];
                    i++;
                }
                generate_email_to_assignee();
            }
        }
        generate_debugger_mail();
    }, 1500);

    // Отправляем запрос в Jira и ждем ответа
}

function generate_description_sr() {
    if (param("select_product") == "ETF" || param("securities") == "ETF") {

        $("#ticker").html(`
<div class='field required'>
  <span>Тикер</span>
  <input class=\"field required secTiker\" data-value-name=\"поле_0\" data-name=\"Тикер\"/>
</div>`);

        $("#name").html(`
<div class='field required'>
  <span>Наименование компании</span>
  <input class=\"field required secName\" data-value-name=\"поле_1\" data-name=\"Наименование компании\"/>
</div>`);


        $("#isin").html(`
<div class='field required'>
  <span>ISIN</span>
  <input class=\"field required secIsin\" data-value-name=\"поле_2\" data-name=\"ISIN\"/>
</div>`);


        $("#exchange").html(`
<div class='field required'>
  <span>Биржа</span>
  <input class=\"field required secExchange\" data-value-name=\"поле_3\" data-name=\"Биржа\"/>
</div>`);


    } else if (param("select_product") == "Акции" || param("securities") == "Акции") {
        $("#ticker").html(`
<div class='field required'>
  <span>Тикер</span>
  <input class=\"field required secTiker\" data-value-name=\"поле_0\" data-name=\"Тикер\"/>
</div>`);

        $("#name").html(`
<div class='field required'>
  <span>Наименование компании</span>
  <input class=\"field required secName\" data-value-name=\"поле_1\" data-name=\"Наименование компании\"/>
</div>`);


        $("#isin").html(`
<div class='field required'>
  <span>ISIN</span>
  <input class=\"field required secIsin\" data-value-name=\"поле_2\" data-name=\"ISIN\"/>
</div>`);


        $("#exchange").html(`
<div class='field required'>
  <span>Биржа</span>
  <input class=\"field required secExchange\" data-value-name=\"поле_3\" data-name=\"Биржа\"/>
</div>`);

        $("#type").html(`
<div class='field active'>
  <span>Тип бумаги</span>
  <select data-name="Тип бумаги" data-value-name="поле_4" class="field secType">
      <option value=""> -выберите- </option>
      <option>АДР</option>
      <option>ГДР</option>
    </select>
</div>`);

    } else if (param("select_product") == "Облигации" || param("securities") == "Облигации") {


        $("#name").html(`
          <div class='field required'>
            <span>Наименование компании</span>
            <input class=\"field required secName\" data-value-name=\"поле_1\" data-name=\"Наименование компании\"/>
          </div>`);


        $("#isin").html(`
<div class='field required'>
  <span>ISIN</span>
  <input class=\"field required secIsin\" data-value-name=\"поле_2\" data-name=\"ISIN\"/>
</div>`);


        $("#exchange").html(`
<div class='field required'>
  <span>Биржа</span>
  <input class=\"field required secExchange\" data-value-name=\"поле_3\" data-name=\"Биржа\"/>
</div>`);


    } else {

        $("#isin").empty();
        $("#ticker").empty();
        $("#name").empty();
        $("#exchange").empty();
        $("#type").empty();

    }
}


function sendDataInFile() {
    let date = date_str(today());
    console.log(date);
    $.post('/departments/processes/test_libraries/feedback/test/writer.php', {
        date: date,
        meta: fields
    }, function(responseText) {
        console.log('Полученные данные', responseText);
    });
}


// function createJiraTaskCustom(fields) {
//     if (typeof fields !== "object") {
//         console.error('Fields must be object');
//         return false;
//     }
//     let data = JSON.stringify({
//         "fields": fields
//     });
//     let request = new XMLHttpRequest();
//     let result;

//     request.onreadystatechange = function() {
//         if (request.readyState == 4) {
//             result = JSON.parse(request.responseText)
//         }
//     }.bind(result);

//     request.open('POST', `/new/api/jira/issue?projectKey=${fields.project.key}`, false);
//     if (typeof data == 'string') {
//         request.setRequestHeader('Content-Type', 'application/json');
//     }
//     request.send(data);

//     return result;
// }

// Регистрируем SR на контакте 
function sr_register_task(description) {
    procedure_add_postmessage({
        "source": "procedure",
        "tasks": [{
                "TASK": "change_sr",
                "DESCRIPTION": description
            },
            {
                "TASK": "change_sr",
                "EXECUTE": "Y"
            }
        ]
    }, after_sr_register);
}


// Завершение цикла. Отключение всех функций. 
function after_sr_register() {
    show_step("6");
    hide("step_10");

    stop_boolean = false;

    clearInterval(timerId);

    if (param("securities") == "Акции" ||
        param("securities") == "Облигации" ||
        param("securities") == "ETF" ||
        param("select_product") == "Акции" ||
        param("select_product") == "Облигации" ||
        param("select_product") == "ETF") {
        $(".buttonAddNew").show();
        $("#addNew").on("click", function() {
            hide("step_6");
            show_step("11");
            generate_description_sr();
            uploadStocks();
            console.log(this);
        });
    } else {
        $(".buttonAddNew").hide();
    }
}

// Отправляем письмо о работе процедуры
function generate_debugger_mail() {
    let array = [];
    let html = "";
    if (!!error_description) {
        debugger_info.push(error_description)
    }

    // Компонент 
    if (!!component) {
        debugger_info.push(component)
    }

    // Продукт
    if (!!product) {
        debugger_info.push(product)
    }

    // Метки
    if (labels.length > 0) {
        debugger_info.push(labels)
    }

    // Система
    if (!!system) {
        debugger_info.push(system)
    }

    // Программа лояльности
    if (!!programm_loyality) {
        debugger_info.push(programm_loyality)
    }

    // Параметры продукта
    if (!!product_params) {
        debugger_info.push(product_params)
    }

    // Функционал
    if (!!functional) {
        debugger_info.push(functional)
    }

    // Услуга
    if (!!service) {
        debugger_info.push(service)
    }

    var resp_text = JSON.stringify(jiraResponse);

    debugger_info.push(text_summary, text_description, resp_text, JSON.stringify(fields));
    if (timer > 0) {
        var counter = "";
        counter = "Времени прошло : " + timer + " секунд<br><br>";
        array.push(counter);
    }

    if (!!error_text) {
        array.push(error_text);
    }

    var index = 0;
    while (index < debugger_info.length) {
        html += `<span>"${debugger_info[index]}"<span><br><br>`;
        index++;
    }

    array.push(html);
    $("#email_transfer1").append(array);
    $(".debugger_email").children(".step-text").find(".email-submit").trigger("click");
}

// Если возникла ошибка отправляем письмо ответсвенным
function generate_email_to_assignee() {
    text = "";
    if (!!component) {
        text += `<span class="text-bold">Компонент : ${component}</span><br>\n`;
    }
    if (!!product) {
        text += `<span class="text-bold">Продукт : ${product}</span><br>\n`;
    }
    if (!!service) {
        text += `<span class="text-bold">Услуга : ${system}</span><br>\n`;
    }
    if (!!functional) {
        text += `<span class="text-bold">Подкатегория :  ${functional}</span><br>\n`;
    }
    if (!!system) {
        text += `<span class="text-bold">Система : ${system}</span><br>\n`;
    }
    if (!!programm_loyality) {
        text += `<span class="text-bold">Программа лояльности : ${product}</span><br>\n`;
    }
    if (!!product_params) {
        text += `<span class="text-bold">Параметры продукта : ${product_params}</span><br>\n`;
    }
    if (!!USER_LOGIN) {
        text += `<span class="text-bold">Пользователь : ${USER_LOGIN}</span><br>`;
    }
    if (!!SIEBEL["s_contact_id"]) {
        text += `<span class="text-bold">Клиент : ${SIEBEL["s_contact_id"]}</span><br>\n`;
    }
    if (!!description) {
        text += `<span class="text-bold">Описание предложения : ${description}</span><br>\n`;
    }
    if (!!error_description) {
        text += `<span class="text-bold">Возникла ошибка : ${error_description}</span><br>\n`;
    }
    if (PROCEDURE_MODE === "manual") {
        console.log("%cСгенерированные параметры : ", "color: #FF8C00;", text);
    }
    $("#email_transfer").append(text);
    $("#step_8").children(".step-text").find(".email-submit").trigger("click");
}

/* Получаем значение статуса из Jira, возвращаем в виде строки нужное */
function generateStatus(name) {
    switch (name) {
        case "Новый":
            return "На Модерации";
        case "На Рассмотрении":
            return "На Рассмотрении";
        case "Пока не планируется":
            return "На Рассмотрении";
        case "Будет реализовано":
            return "В работе";
    }
}

/* генерируем тэги для отображения */
function generate_tags_to_search(obj) {
    let array = [];
    for (key in obj.fields) {
        if (key.match("customfield_")) {
            if (obj["fields"][key] != null && obj["fields"][key]["value"] != undefined) {
                array.push(obj["fields"][key]["value"]);
            }
        }
    }
    return array.join(", ").toLowerCase();
}


function checkArratText() {
    // !ВАЖНО. Для корректной работы, все элементы и их названия должны строго соотвествовать названиям в jira
    let strComponent = "";
    let strProduct = "";
    let strService = "";
    let strSystem = "";
    let strProductParams = "";
    let strFunctional = "";
    let findText = "";
    // если компонент не равен null и если элемент существует (для отладки)
    if (component != null && !!component) {
        strComponent = " AND component = " + "\"" + component + "\"";
    }
    if (product != null && !!product) {
        strProduct = " AND \"Продукт\" = " + "\"" + product + "\"";
    }
    if (!!product_params && product_params != null) {
        strProductParams = " AND \"Параметры продукта\" = " + "\"" + product_params + "\"";
    }
    if (!!functional && functional != null) {
        strFunctional = " AND \"Функционал\" = " + "\"" + functional + "\"";
    }
    if (!!service && service != null) {
        strService = " AND \"Услуга\" = " + "\"" + service + "\"";
    }
    if (!!system && system != null) {
        strSystem = " AND \"Сервис\" = " + "\"" + system + "\"";
    }
    findText = strComponent + strProduct + strService + strSystem + strProductParams + strFunctional;
    let cuctomText = "project = FEEDBACK AND status in (\"На Рассмотрении\", \"Будет реализовано\", \"Пока не планируется\") AND resolution = Unresolved" + findText + " ORDER BY cf[10702] DESC";

    console.log("pull text : ", cuctomText);
    // Строка, которую будем возвращать в поисковик
    return cuctomText;
}

function genAppropriateArray() {
    jiraObject = []; // Очищаем массив перед запросом 
    // Получаем акутуальный массив задач (не более 50) - техническое ограничение

    jiraObject = typeof searchJiraIssues("FEEDBACK", checkArratText()) !== "undefined" ? searchJiraIssues("FEEDBACK", checkArratText()).issues : []; // Сделал для случаев, если возвращается ошибка. Пока думаю, как оптимизировать.

    console.log(typeof jiraObject);
    console.log(jiraObject);

    return jiraObject;


}

function todoAfter(callback) {
    generateSCard();
    callback();
}

/* Для поиска */
function generateSCard(id) {
    // для повторного вызова 
    if (!id || typeof id === "undefined") {
        id = "";
    }
    // Тут мы получаем массив всех элементов, за которые уже проголосовали 
    let activateArr = [];
    $("[s-card-box]").each(function() {
        if ($(this).children().find(".icon").hasClass("hidden")) {
            activateArr.push($(this).attr("id"));
        }
    });

    $(".search-panel").empty();
    let html = "";

    /* Сортируем по топу голосов */
    const array = genAppropriateArray().sort(function(a, b) {
        if (PROCEDURE_MODE === "manual") {
            console.log(
                "значение a", a.fields.customfield_10702,
                "значение b", b.fields.customfield_10702
            ); /* Для отладки */
        }
        if (a.fields.customfield_10702 < b.fields.customfield_10702) {
            return 1;
        } else if (a.fields.customfield_10702 > b.fields.customfield_10702) {
            return -1;
        } else {
            return 0;
        }
    });
    /* отображаем задачи */
    for (const i in array) {
        if (i < maxTasks) {
            const elem = array[i];

            if (elem["fields"]["status"]["name"] /* != "Новый"*/ ) {
                html += `
        <div id="${elem["id"]}" s-card-box card-tags="${generate_tags_to_search(elem)}">
          <div s-card-top>
            <div s-card-title>
              <span class="text-bold">${elem["fields"]["summary"]}</span>
            </div>
            <!--a s-card-key class="text-bold link" target="_blank" href="https://jira2.tcsbank.ru/browse/${elem["key"]}">
              ${elem["key"]}	
            </a-->
          </div>
          <div search-element>
            <p>
              ${elem["fields"]["description"]}
            </p>
          </div>
          <hr class="line" style="">
          <div s-card-bottom>
            <div s-card-title>
              <span s-card-count class="text-bold">${elem["fields"]["customfield_10702"]}</span>
              <img class="icon" src="/departments/processes/test_libraries/feedback/images/icon/ic-like.png">
            </div>
            <span s-card-status="${elem["fields"]["status"]["statusCategory"]["colorName"]}">
              ${generateStatus(elem["fields"]["status"]["name"])}
              </span>
          </div>
        </div>`
            }
        }
    }
    $(".search-panel").append(html);


    // При нажатии на лайк повторно рисуем список, но через полученный ID задачи скрываем кнопку
    $("[s-card-box]").each(function() {
        if (activateArr.find(item => item == $(this).attr("id")) != undefined) {
            $(this).children().find(".icon").addClass("hidden");
        }
    });


    /* Навешиваем событие клика по элементу */
    $(".icon").on("click", function() {
        if (PROCEDURE_MODE === "manual") {
            console.log("поиск id", $(this).parent().parent().parent().attr("id"));
        }
        let count = Number($(this).parent().children().first().html());
        count++;
        $(this).parent().children().first().html(count);
        let id;
        id = $(this).parent().parent().parent().attr("id");
        if (PROCEDURE_MODE === "manual") {
            console.log("id задачи", id);
        }
        let target = jiraObject.find(item => item.id == id);
        incrementJiraVotes(target.key, 10702);
        if (PROCEDURE_MODE === "manual") {
            console.log("Найденная задача", target);
            console.log("key задачи", target.key);
        }
        procedure_add_postmessage({
            "source": "procedure",
            "tasks": [{
                "TASK": "add_new_sr",
                "SR_CODE": "Feedback.CustomerOffer"
            }]
        }, () => {
            const localText = target.key + "\n" + target.fields.description;
            procedure_add_postmessage({
                "source": "procedure",
                "tasks": [{
                        "TASK": "change_sr",
                        "DESCRIPTION": localText
                    },
                    {
                        "TASK": "change_sr",
                        "EXECUTE": "Y"
                    }
                ]
            }, () => {});
        });

        $(this).addClass("hidden");
        generateSCard(id);
    });


    /* запускаем поиск */
    $("body").on("input", "textarea.description-text", function(event) {
        Search.start($(this).val());
    });
};


//====================================================================================================
// * 
// *  Для ценных бумаг и фин. инструментов
// * 
//====================================================================================================


const FindStocks = {
    findIsin: function(search_str) {
        if (search_str.length > 0) {
            $("[non-link]").hide();
            $("[non-link]").removeClass("search-item");

            var keywords = search_str.split(" ");

            $("[non-link]").children().find(".f_isin").each(function() {
                var text = $(this).text().toUpperCase();
                var foundKeywords = 0;

                for (var i in keywords) {
                    var keyword = keywords[i];

                    if (~text.indexOf(keyword.toUpperCase()) || ~text.indexOf(Search.convert_symbols("en", "ru", keyword).toUpperCase()) || ~text.indexOf(Search.convert_symbols("ru", "en", keyword).toUpperCase())) {
                        foundKeywords++;
                    }
                }

                if (foundKeywords == keywords.length) {
                    $(this).parent().parent().parent().parent().each(function() {
                        $(this).show();
                        $(this).addClass("search-item");
                    });
                }
            });

        } else {
            $("[non-link]").show();
            $("[non-link]").removeClass("search-item");
        }
    },
    findTicker: function(search_str) {
        if (search_str.length > 0) {
            $("[non-link]").hide();
            $("[non-link]").removeClass("search-item");

            var keywords = search_str.split(" ");

            $("[non-link]").children().find(".f_ticker").each(function() {
                var text = $(this).text().toUpperCase();
                var foundKeywords = 0;

                for (var i in keywords) {
                    var keyword = keywords[i];

                    if (~text.indexOf(keyword.toUpperCase()) || ~text.indexOf(Search.convert_symbols("en", "ru", keyword).toUpperCase()) || ~text.indexOf(Search.convert_symbols("ru", "en", keyword).toUpperCase())) {
                        foundKeywords++;
                    }
                }
                if (foundKeywords == keywords.length) {
                    $(this).parent().parent().parent().each(function() {
                        $(this).show();
                        $(this).addClass("search-item");
                    });
                }
            });

        } else {
            $("[non-link]").show();
            $("[non-link]").removeClass("search-item");
        }
    },
    findName: function(search_str) {
        if (search_str.length > 0) {
            $("[non-link]").hide();
            $("[non-link]").removeClass("search-item");
            var keywords = search_str.split(" ");
            $("[non-link]").children().find(".f_name").each(function() {
                var text = $(this).text().toUpperCase();
                var foundKeywords = 0;
                for (var i in keywords) {
                    var keyword = keywords[i];
                    if (~text.indexOf(keyword.toUpperCase()) || ~text.indexOf(Search.convert_symbols("en", "ru", keyword).toUpperCase()) || ~text.indexOf(Search.convert_symbols("ru", "en", keyword).toUpperCase())) {
                        foundKeywords++;
                    }
                }
                if (foundKeywords == keywords.length) {
                    $(this).parent().parent().parent().parent().each(function() {
                        $(this).show();
                        $(this).addClass("search-item");
                    });
                }
            });
        } else {
            $("[non-link]").show();
            $("[non-link]").removeClass("search-item");
        }
    }
}

const GenerateStocksCard = {
    generate: function(array, type) {
        let html = "";
        for (const i in array) {
            const item = array[i];
            html += `
      <a title="перейти на сайт" non-link target="blank" href="https://www.tinkoff.ru/invest/${type}/${item["ticker"]}/">
        <div class="horizontal between card-box" style="padding: 15px;">
          <div class="vertical between">
            <div class="horizontal">
              <span class="text-bold f_name" style="color: #333;">${item["name"]}</span>
            </div>
            <div class="horizontal">
              <span style="color: #909090;" class="f_isin">${item["ISIN"]}</span>
            </div>
          </div>
              <div class="vertical">
            <span class="text-bold f_ticker" style="color: #333;">${item["ticker"]}</span>
          </div>
        </div>
      </a>`;
        }
        $("#stocksPanel").empty();
        $("#stocksPanel").append(html);
    }
}

// Для загрузки ценных бумаг для Инвестиций 
function uploadStocks() {
    let stocksArray = [];
    let bondsArray = [];
    let etfArray = [];
    let x;

    $.ajax({
        async: false,
        url: "https://config.tinkoff.ru/resources?name=trading_stocks",
        method: "GET",
        success: function(data) {
            x = data;
            let z = x.result.value;
            let y = Object.keys(z);

            for (var i in y) {
                if (z[y[i]]["isOTC"] != 1 && z[y[i]]["showAuth"] == 1 && z[y[i]]["showNotAuth"] == 1) {
                    if (z[y[i]]["type"] == "stock") {
                        stocksArray.push({
                            "name": z[y[i]]["name"],
                            "ticker": z[y[i]]["ticker"],
                            "ISIN": y[i]
                        });
                    } else if (z[y[i]]["type"] == "bonds") {
                        bondsArray.push({
                            "name": z[y[i]]["name"],
                            "ticker": z[y[i]]["ticker"],
                            "ISIN": y[i]
                        });
                    } else if (z[y[i]]["type"] == "etf") {
                        etfArray.push({
                            "name": z[y[i]]["name"],
                            "ticker": z[y[i]]["ticker"],
                            "ISIN": y[i]
                        });
                    }
                }
            }

            if (param("select_product") === "Акции" || param("securities") === "Акции") {
                GenerateStocksCard.generate(stocksArray, "stocks");
            } else if (param("select_product") === "Облигации" || param("securities") === "Облигации") {
                GenerateStocksCard.generate(bondsArray, "bonds");
            } else if (param("select_product") === "ETF" || param("securities") === "ETF") {
                GenerateStocksCard.generate(etfArray, "etfs");
            }

            $("body").on("input", ".secTiker", function() {
                FindStocks.findTicker($(this).val());
            });
            $("body").on("input", ".secName", function() {
                FindStocks.findName($(this).val());
            });
            $("body").on("input", ".secIsin", function() {
                FindStocks.findIsin($(this).val());
            });
        }
    });

}


function saveStock(target) {
    let parent = $(target).parent().parent() // Получаем ste-text
    let fields = $(parent).children().find("input, textarea, select"); // Находим все его дочерние элементы типа input, textarea и select
    let requiredInputs = [];
    $(fields).each(function() { // Для каждого найденного элемента
        if ($(this).val() == "" && $(this).hasClass("required")) {
            $(this).parent("div.field").addClass("input-error");
            requiredInputs.push($(this));
        } else {
            $(this).parent("div.field").removeClass("input-error");
        }
    });

    if (requiredInputs.length > 0) {
        show_error(USER_FIRST_NAME + ", заполни все поля!");
    } else {
        let obj = {};
        if (product_params == "ETF") {
            obj = {
                "ticker": $(".secTiker").val(),
                "name": $(".secName").val(),
                "isin": $(".secIsin").val(),
                "exchange": $(".secExchange").val()
            };
        } else if (product_params == "Облигации") {
            name = $(".secName").val();
            exchange = $(".secExchange").val();
            isin = $(".secIsin").val();
            obj = {
                "name": $(".secName").val(),
                "isin": $(".secIsin").val(),
                "exchange": $(".secExchange").val()
            };
        } else if (product_params == "Акции") {
            obj = {
                "ticker": $(".secTiker").val(),
                "name": $(".secName").val(),
                "isin": $(".secIsin").val(),
                "exchange": $(".secExchange").val(),
                "type": $(".secType").val()
            };
        }


        if (PROCEDURE_MODE == "manual") {
            console.log(obj);
        }

        if (obj) {
            const arr = obj.name.split(" ");
            labels = arr;
            description = "Добавление новой бумаги.\n Данные для добавления: " + JSON.stringify(obj);
            text_description = generate_text_description(description);
            text_summary = generate_summary();
            start_timer();
            hide("step_11");
            if (PROCEDURE_MODE == "auto") {
                create_sr();
            } else {
                hide("step_1");
                show_step("10");
                generate_input_data();
            }
        } else {
            console.error("Object not found");
        }
    }
}


// /* Для отладки */
// function debugRequest() {
//     var x =
//         `project = FEEDBACK AND status in ("На Рассмотрении", "Будет реализовано", "Пока не планируется") AND resolution = Unresolved AND component = "Инвестиции"`;

//     $.ajax({
//         method: 'GET',
//         url: `/new/api/jira/search?jql=${encodeURIComponent(x)}&projectKey=FEEDBACK`,
//         success: function(data) {
//             console.log(data);
//         },
//     });


//     function createJiraTask(fields) {
//     	if (typeof fields !== 'object') {
//     		console.error('Fields must be object');
//     		return false;
//     	}
//     	let data = JSON.stringify({
//     		fields: fields,
//     	});
//     	let request = new XMLHttpRequest();
//     	let result;

//     	request.onreadystatechange = function() {
//     		if (request.readyState == 4) {
//     			result = JSON.parse(request.responseText);
//     		}
//     	}.bind(result);

//     	request.open('POST', `/new/api/jira/issue?projectKey=${fields.project.key}`, false);
//     	if (typeof data == 'string') {
//     		request.setRequestHeader('Content-Type', 'application/json');
//     	}
//     	request.send(data);

//     	return result;
//     }

//     function searchJiraIssues(projectKey, jql) {
//     	if (typeof jql !== 'string') {
//     		console.error('JQL must be a string');
//     		return false;
//     	}
//     	if (typeof projectKey !== 'string') {
//     		console.error('Project must be a string');
//     		return false;
//     	}

//     	let request = new XMLHttpRequest();
//     	let result;

//     	request.onreadystatechange = function() {
//     		if (request.readyState == 4) {
//     			result = JSON.parse(request.responseText);
//     		}
//     	}.bind(result);

//     	request.open('GET', `/new/api/jira/search?jql=${encodeURIComponent(jql)}&projectKey=${projectKey}`, false);
//     	request.send();

//     	return result;
//     }

//     function incrementJiraVotes(issueKey, customFieldId) {
//     	if (typeof issueKey !== 'string') {
//     		console.error('isseuKey must be a string');
//     		return false;
//     	}
//     	if (typeof customFieldId !== 'number') {
//     		console.error('customFieldId must be a number');
//     		return false;
//     	}

//     	let request = new XMLHttpRequest();
//     	let result;

//     	request.onreadystatechange = function() {
//     		if (request.readyState == 4) {
//     			result = JSON.parse(request.responseText);
//     		}
//     	}.bind(result);

//     	let formData = new FormData();
//     	formData.append('issueKey', issueKey);
//     	formData.append('voteField', customFieldId);

//     	request.open('POST', `/new/jira/filter/increment-votes`, false);
//     	request.send(formData);

//     	return result;
//     }

// }