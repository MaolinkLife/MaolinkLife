    /* SPOILER */

    $(function () {



      $("[mui-flex-spoiler]").each(function () {
        const spoiler = $(this);
        const content = $(this).html();
        const title = spoiler.attr('data-title');
        const active = spoiler.attr('active');
        const size = spoiler.attr('data-size');
        const color = spoiler.attr('data-color');
        const margin = spoiler.attr('data-margin');


        const icon = '<svg _ngcontent-ral-c4="" focusable="false" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path _ngcontent-ral-c4="" d="M15.3 9.7c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-3.3 3.3c-.8.8-2 .8-2.8 0l-3.3-3.3c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L12 13l3.3-3.3z" fill="currentColor"></path></svg>';

        const html = `
              <div mui-flex-spoiler-box mui-flex-direction="vertical" style="max-width: ${size}; margin: ${margin}">
                <div ${ color ? 'mui-color="'+color+'"' : ''} mui-flex-spoiler-title style="margin: 0;" ${ typeof active != 'undefined' ? 'active' : ''}>
                  <div mui-flex-text="small">
                    ${title}
                  </div>
                  <div mui-flex-icon type="arrow_down">
                   ${icon}
                  </div>
                </div>
                <div mui-flex-direction="vertical" mui-flex-spoiler-content style="display: none;">
                  ${content}
                </div>
              </div>`;

        spoiler.replaceWith(html);
      });


      $("[mui-flex-spoiler-title]").on('click', function () {
        const icon = $(this).children('[mui-flex-icon]');
        $(this).toggleClass('active');
        icon.toggleClass('rotate');
        const content = $(this).siblings('[mui-flex-spoiler-content]');
        console.log(content.is(':visible'))
        content.slideToggle(function () {});

      });

      $("[mui-flex-spoiler-title]").each(function () {
        console.log($(this).attr('active'));
        const attr = $(this).attr('active');
        if (typeof attr != 'undefined') {
          $(this).trigger('click');
        }
      })



      $('[mui-spoiler-title]').append("<div class=\"arrow\"><div class=\"icon\"></div></div>");

      $('div[mui-spoiler-title]').click(function () {
        console.log(this);
        $(this).toggleClass('active');
        $(this).parent().children('div[mui-spoiler-content]').slideToggle(400);
        $(this).children(".arrow").children(".icon").toggleClass('active-spoiler');
        return false;
      });


      $("[mui-spoiler-box]").each(function () {
        const attr = $(this).attr("active");
        if (typeof attr !== undefined && typeof attr !== "undefined" && attr !== false) {
          $(this).children("div[mui-spoiler-title]").trigger('click');
          $(this).children('div[mui-spoiler-content]').slideToggle();
        }
      });



    });