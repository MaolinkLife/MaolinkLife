    /* SPOILER */

    $(function () {



      $("[mui-flex-spoiler]").each(function () {
        const spoiler = $(this);
        const content = $(this).html();
        const title = spoiler.attr('data-title');
        const active = spoiler.attr('active');
        const size = spoiler.attr('data-size');
        const color = spoiler.attr('data-color');

        const icon = '<svg _ngcontent-ral-c4="" focusable="false" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path _ngcontent-ral-c4="" d="M15.3 9.7c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-3.3 3.3c-.8.8-2 .8-2.8 0l-3.3-3.3c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L12 13l3.3-3.3z" fill="currentColor"></path></svg>';

        const html = `
              <div mui-flex-spoiler-box mui-flex-direction="vertical" style="max-width: ${size};">
                <div ${ color ? 'mui-color="'+color+'"' : ''} mui-flex-spoiler-title ${ typeof active != 'undefined' ? 'active' : ''}>
                  <div mui-flex-text="small">
                    ${title}
                  </div>
                  <div mui-flex-icon type="arrow_down">
                   ${icon}
                  </div>
                </div>
                <div mui-flex-direction="vertical" mui-flex-spoiler-content>
                  ${content}
                </div>
              </div>`;
        spoiler.replaceWith(html);
      });


      $("[mui-flex-spoiler-title]").on('click', function () {
        const icon = $(this).children('[mui-flex-icon]');
        $(this).toggleClass('active');
        icon.toggleClass('rotate');
        const content = $(this).siblings('[mui-flex-spoiler-content]');
        if (content.is(':visible')) {
          content.slideUp(300);
        } else {
          content.slideDown(300);
        }
      });

      $("[mui-flex-spoiler-title]").each(function () {
        console.log($(this).attr('active'));
        const attr = $(this).attr('active');
        if (typeof attr != 'undefined') {
          $(this).trigger('click');
        }
      })
    });