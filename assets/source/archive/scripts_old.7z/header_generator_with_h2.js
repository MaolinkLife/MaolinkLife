
$(function() {
	array_target = $("h2");
	var i = 0;
	var text = "";
	var id = "";
	var linking = "";
	var text_link = "";

	while (i < array_target.length) {
	    text = $(array_target[i]).text();
	    id = "link_to_"+i; 

	    $(array_target[i]).attr("id", id);
	    linking = "<a href=\"#"+id+"\">"+text+"</a>";
	    $("ol[header-target]").append("<li>"+linking+"</li>");
	    i++;
	    }
	});
